import React from "react";
import styled from "styled-components";
import ImgPath from "./img/hero_img.jpg";
import "./styles.css";
